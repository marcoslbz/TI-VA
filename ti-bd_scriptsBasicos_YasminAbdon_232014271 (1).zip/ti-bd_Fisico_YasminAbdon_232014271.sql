--  === << Employees (test_db) >>  ===
--  
--        SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 28/09/2026
-- Autor(es) ..............: Yasmin Sousa Abdon, Pedro Augusto Moretti Moreira
-- Banco de Dados .........: MySQL 9.7
-- Base de Dados (nome) ...: yasminabdon
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 00 Visoes
--         => 00 Perfis (role)
--         => 00 Usuarios
--         => 00 Sequencias
--         => 00 Triggers
--         => 00 Procedimentos
--         => 00 Funcoes
-- 
-- --------------------------------------------------------- -

CREATE TABLE DEPARTMENTS (
  dept_no   CHAR(4)     NOT NULL,
  dept_name VARCHAR(40) NOT NULL,
  CONSTRAINT pk_departments PRIMARY KEY (dept_no),
  CONSTRAINT uq_departments_dept_name UNIQUE (dept_name)
) ENGINE=InnoDB;

CREATE TABLE EMPLOYEES (
  emp_no     INT           NOT NULL,
  birth_date DATE          NOT NULL,
  first_name VARCHAR(14)   NOT NULL,
  last_name  VARCHAR(16)   NOT NULL,
  gender     ENUM('M','F') NOT NULL,
  hire_date  DATE          NOT NULL,
  CONSTRAINT pk_employees PRIMARY KEY (emp_no)
) ENGINE=InnoDB;

CREATE TABLE DEPT_EMP (
  emp_no    INT     NOT NULL,
  dept_no   CHAR(4) NOT NULL,
  from_date DATE    NOT NULL,
  to_date   DATE    NOT NULL,
  CONSTRAINT pk_dept_emp PRIMARY KEY (emp_no, dept_no, from_date),
  CONSTRAINT fk_dept_emp_employees FOREIGN KEY (emp_no)
    REFERENCES EMPLOYEES (emp_no) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_dept_emp_departments FOREIGN KEY (dept_no)
    REFERENCES DEPARTMENTS (dept_no) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE SALARIES (
  emp_no    INT  NOT NULL,
  salary    INT  NOT NULL,
  from_date DATE NOT NULL,
  to_date   DATE NOT NULL,
  CONSTRAINT pk_salaries PRIMARY KEY (emp_no, from_date),
  CONSTRAINT fk_salaries_employees FOREIGN KEY (emp_no)
    REFERENCES EMPLOYEES (emp_no) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;
