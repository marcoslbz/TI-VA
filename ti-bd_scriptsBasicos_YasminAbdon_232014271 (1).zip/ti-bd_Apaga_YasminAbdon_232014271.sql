--  === << Employees (test_db) >>  ===
--  
--        SCRIPT DE REMOCAO (DDL)
--
-- Data Criacao ...........: 28/09/2026
-- Autor(es) ..............: Yasmin Sousa Abdon, Pedro Augusto Moretti Moreira
-- Banco de Dados .........: MySQL 9.7
-- Base de Dados (nome) ...: yasminabdon
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 00 Visoes
--         => 00 Perfis (role)
--         => 00 Usuarios
--         => 00 Sequencias
--         => 00 Triggers
--         => 00 Procedimentos
--         => 00 Funcoes
-- 
-- --------------------------------------------------------- -

DROP TABLE IF EXISTS SALARIES;
DROP TABLE IF EXISTS DEPT_EMP;
DROP TABLE IF EXISTS EMPLOYEES;
DROP TABLE IF EXISTS DEPARTMENTS;
